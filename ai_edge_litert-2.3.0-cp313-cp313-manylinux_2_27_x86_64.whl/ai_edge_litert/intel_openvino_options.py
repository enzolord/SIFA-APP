# Copyright 2026 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Intel OpenVINO-specific options for LiteRT compiled models."""

import dataclasses
import enum
import os
from typing import Any, Optional

# pylint: disable=g-import-not-at-top
if not os.path.splitext(__file__)[0].endswith(
    os.path.join("ai_edge_litert", "intel_openvino_options")
):
  from ai_edge_litert.litert_wrapper.compiled_model_wrapper import option_utils
else:
  from ai_edge_litert import option_utils
# pylint: enable=g-import-not-at-top


class IntelOpenVinoGraphBackend(enum.IntEnum):
  """Intel OpenVINO graph types (target devices for a partition)."""

  CPU = 0
  GPU = 1
  NPU = 2


class IntelOpenVinoPerformanceMode(enum.IntEnum):
  """Intel OpenVINO performance modes."""

  LATENCY = 0
  THROUGHPUT = 1
  CUMULATIVE_THROUGHPUT = 2


@dataclasses.dataclass
class IntelOpenVinoOptions:
  """Intel OpenVINO-specific options for a LiteRT compiled model."""

  GRAPH_BACKEND = IntelOpenVinoGraphBackend
  PERFORMANCE_MODE = IntelOpenVinoPerformanceMode

  graph_backend: Optional[IntelOpenVinoGraphBackend] = None
  performance_mode: Optional[IntelOpenVinoPerformanceMode] = None
  configs_map: dict[str, str] = dataclasses.field(default_factory=dict)
  # Cross-partition weight sharing. Leave as None to use the plugin default
  # (enabled); set to False to force standalone per-partition bytecode.
  enable_weight_sharing: Optional[bool] = None

  def _as_flat_kwargs(self) -> dict[str, Any]:
    """Returns kwargs for the internal pybind wrapper."""
    return {
        "intel_openvino_graph_backend": option_utils.optional_enum_to_int(
            self.graph_backend
        ),
        "intel_openvino_performance_mode": option_utils.optional_enum_to_int(
            self.performance_mode
        ),
        "intel_openvino_configs_map": dict(self.configs_map),
        "intel_openvino_enable_weight_sharing": (
            option_utils.optional_bool_to_int(self.enable_weight_sharing)
        ),
    }
